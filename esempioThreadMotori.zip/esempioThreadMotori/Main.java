import java.util.Random;
class Main {

	public static void main(String[] args){
		
		int n = 5; // 5 motori
		int numeroSimulazioni = 1;
	    
	    Motore[] gruppoMotori = new Motore[n];
	    
	    for (int simulazione = 0; simulazione < numeroSimulazioni; simulazione++)
	    {
	    	System.out.println("----- Ciclo di simulazione n. " + simulazione + " -----");
		    for (int i=0; i < n; i++ )
		    {
		    	gruppoMotori[i] = new Motore();
		    	((Motore)gruppoMotori[i]).setVelocita(numeroCasuale(0,100));
		    	((Motore)gruppoMotori[i]).setRotazione(numeroCasuale(0,3)-1);
		    	((Motore)gruppoMotori[i]).setTempo(numeroCasuale(2000,5000));
		    	((Motore)gruppoMotori[i]).setIdMotore("Motore##"+i+"##");
		    }
		    	
		    System.out.println("Avvio di tutti i motori! --> ");
		    
		    for (int i=0; i < n; i++ )
		    	gruppoMotori[i].start();		    
        System.out.println(" Metodo MAIN: Stato ATTESA <-- il medoto Main e' in stato di attesa di fine lavoro dei motori!");
        try { for (int i=0; i < n; i++) gruppoMotori[i].join(); } catch(Exception e) {}
        
		    

        
        boolean motoriFermi = false;
        while (!motoriFermi)
          {
            try { Thread.sleep(500); } catch(Exception e) { }
            motoriFermi = true;
            for (int i=0; i < n; i++ )
              {
                motoriFermi &= ! gruppoMotori[i].isAlive();
                System.out.println("Stato Motore[" + i + "] --> " + (gruppoMotori[i].isAlive()?"Movimento":"Fermo"));
              }
          }
        
        System.out.println(" Metodo MAIN: Stato TERMINATO!");
	    }
	    
	  }
	
	//------------------------------------------------------------------------------
	
	static Random gen = new Random();
	static int numeroCasuale(int da,int a)
	{
		return (int)(da+gen.nextInt(a-da));
	}
}
