class Motore extends Thread {

	public void run()
	  {
		System.out.println(this.getIdMotore() + " -> Fase A -> " + this.toString());
		
		try { Thread.sleep(this.getTempo()); } 
		catch (InterruptedException e) { System.out.println(e); }
		
		this.setRotazione(INVERSIONE*this.getRotazione());
		this.setVelocita((int)(getVelocita()/2));

    System.out.println(this.getIdMotore() + " -> Fase A -> " + this.toString());
		
		try { Thread.sleep(this.getTempo()); } 
		catch (InterruptedException e) { System.out.println(e); }

    System.out.println(this.getIdMotore() + " -> Terminazione -> " + this.toString());
	  }
	
	//------------------------------------------------------------------------------
	
	public static final int ORARIO = 1;
	public static final int ANTIORARIO = -1;
	public static final int FERMO = 0;
	public static final int INVERSIONE = -1;
	private int velocita = 0;
	private int rotazione = 0;
	private int tempo = 0;
	String idMotore = new String();
	
	public Motore(int v, int r, int t) {
		this.velocita = v;
		this.rotazione = r;
		this.tempo = t;
	}
	
	public Motore() {
		this.velocita = 0;
		this.rotazione = FERMO;
	}

	public int getVelocita() {
		return velocita;
	}

  public void setVelocita(int velocita) {
		this.velocita = velocita;
	}
	public void setTempo(int tempo) {
		this.tempo = tempo;
	}
	
	public int getTempo() {
		return tempo;
	}

	public int getRotazione() {
		return rotazione;
	}

	public void setRotazione(int rotazione) {
		this.rotazione = rotazione;
	}
	
	public String getIdMotore() {
		return idMotore;
	}

	public void setIdMotore(String idM) {
		this.idMotore = idM;
	}

	@Override
	public String toString() {
		return "motore [rotazione=" + this.getRotazione() + ", velocita'=" + this.getVelocita() + ", tempo=" + this.getTempo() + "]";
	}
	
}
